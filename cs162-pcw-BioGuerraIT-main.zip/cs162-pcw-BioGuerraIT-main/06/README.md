## The Flask Microframework

Flask is called a microframework because it is lightweight and minimalistic,
providing the bare bones of features a simple web application requires. It
supports basic HTTP requests, connections to databases and a frontend, but
is easily extensible to a wide variety of other requirements.

Web/app frameworks have largely come to define modern app development, and you
will almost certainly run into them again at some point in the future. Try to
get a solid grasp of what frameworks accomplish, and why we have them! They
might seem complex and overwhelming at first, but they are the glue that makes
every part work with each other in a functioning application. They give us a
template/roadmap, or backbone if you will, to create dynamic and fun
applications in a much more efficient manner.

## Pre-class work

1. Work through thhe tutorial in question 1, and commit your code to your PCW repo.
2. Answer all questions in Question 2, which will strengthen your knowledge with Flask, and commit the answers to your PCW repo.

### 1. Flask tutorial

Work through the official Flask tutorial:
https://flask.palletsprojects.com/en/2.3.x/tutorial/

This official Flask tutorial introduces the main features of Flask.
The focus today is on defining templates and views which are covered in the sections up
to the end of the _Blog Blueprint_ section. We cover topics like testing and deployment
later in the course.

- Work though the tutorial one section at a time.
- Use the internet and AI tools to help you debug if you get stuck.
- Research any code that you don't understand.
- **Commit the code to your PCW repo before you come to class**

### 2. Answer the following questions in a README.md file

### 1. Flask as a Microframework
Flask is often referred to as a microframework because it is lightweight and only provides the core tools needed to get a web application up and running, with the flexibility to extend its capabilities through extensions. This minimalistic approach makes Flask easy to understand and work with, especially for small to medium-sized web applications, or for situations where a simple, yet robust, framework is needed without the overhead of unused features.

### 2. Roles of Components in a Flask App
- **Templates**: These are files that contain static data as well as placeholders for dynamic data. Flask uses a templating engine called Jinja2 to render templates, allowing the seamless integration of Python code with HTML.
- **Static Files**: These include CSS, JavaScript, and image files that are not dynamically generated and remain the same for all users. Flask serves these files from the `static` directory.
- **requirements.txt**: This file lists all the Python packages that your app depends on. You can generate this file using `pip freeze` and others can install all the required packages with `pip install -r requirements.txt`.
- **Virtual Environment (`venv`)**: A virtual environment is an isolated Python environment where you can install packages and dependencies without affecting other Python projects. It's a best practice to use a virtual environment for each project to avoid version conflicts.
- **render_template**: This is a function in Flask used to render a template file, passing any necessary data to the template. It's commonly used to dynamically generate HTML content.
- **redirect**: A function in Flask used to redirect a user to a different endpoint. This is often used after handling form data to redirect a user to a different page.
- **url_for**: A function used to generate URLs for a particular function or endpoint, which is useful for dynamic URL generation.
- **session**: A way to store information specific to a user from one request to the next. This is implemented on top of cookies for you and signs the cookies cryptographically.

### 3. Flask Commands Explanation
- `$ pip3 install -r requirements.txt`: This command is used to install all the Python packages that are listed in the `requirements.txt` file. It ensures that all the dependencies for the Flask app are met.
- `$ export FLASK_APP=app`: This command sets an environment variable `FLASK_APP` to the entry file of your Flask application, in this case, `app`. This tells Flask which module to run.
- `$ python3 -m flask run`: This command is used to run the Flask application. It serves the app on a local development server and is equivalent to running `flask run` in the command line.

### 4. Methods to Run a Flask App
- Using `export FLASK_APP=app.py` followed by `python3 -m flask run` sets the `FLASK_APP` environment variable and then runs the Flask application. This is the recommended way as it gives more flexibility and is explicitly clear about which app to run.
- Using `python3 app.py` directly runs the Python script. This method is straightforward but less flexible. It relies on the `if __name__ == "__main__":` block to run the app.

### 5. Importance of Defining Specific Versions in `requirements.txt`
Specifying versions ensures that your app works consistently across all environments. Different versions of libraries may have different functionalities, and not pinning them might lead to unexpected behavior or incompatibility. You can find the versions you should use by testing your app with different versions and ensuring it works as expected, or by following the versions specified in the documentation of the libraries.

### 6. Role of `@app.route`
`@app.route` is a decorator that tells Flask what URL should trigger the following function. The `methods` argument specifies which HTTP methods are allowed. Here, it's set to `['GET']`, which means the route is accessible only via GET requests. If `methods` is not specified, it defaults to `['GET']`.

### 7. Decorators in Flask
A decorator in Flask is a special function that wraps another function to extend its behavior without permanently modifying it. In Flask, decorators are used to associate URLs with Python functions, which makes it easy to define routes and views.

### 8. `config` Attribute in Flask
The `config` attribute in a Flask app is used to store configuration variables. You can set `TESTING=True` or `SECRET_KEY='abc'` by directly assigning the values to the `config` dictionary like `app.config['TESTING'] = True` or `app.config['SECRET_KEY'] = 'abc'`.

### 9. JSON and Its Usage
JSON (JavaScript Object Notation) is a lightweight data interchange format that is easy for humans to read and write and easy for machines to parse and generate. It's commonly used for transmitting data in web applications (e.g., sending data from the server to the client, so it can be displayed on a web page, or vice versa). Using JSON facilitates data exchange between clients and servers using different technologies.

### 10. Default Host and Port in Flask and Customization
The default host and port for a Flask app are `localhost` (or `127.0.0.1`) and `5000`, respectively. You can change the host and port by passing them as arguments to the `app.run()` method like `app.run(host='0.0.0.0', port=8080)`.

Commit your answers to a README.md file in the repo. They don't have to be extensive
written answers, just enough to prompt you into giving a complete verbal answer
if you are called on.

**Please commit your work to your PCW repo and push it to github before class!**