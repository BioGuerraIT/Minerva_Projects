 // JavaScript for Logout Button
 document.getElementById('logoutButton').addEventListener('click', function() {
    window.location.href = 'login.html'; // Redirect to login page
});

// Drag and Drop Script
function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
}

// Initialize Drag and Drop for tasks and columns
document.addEventListener('DOMContentLoaded', (event) => {
    let tasks = document.querySelectorAll('.task');
    let columns = document.querySelectorAll('.column');

    tasks.forEach(task => {
        task.setAttribute('draggable', true);
        task.setAttribute('id', 'task' + Math.random().toString(36).substr(2, 9)); // Unique ID for each task
        task.addEventListener('dragstart', drag);
    });

    columns.forEach(column => {
        column.addEventListener('dragover', allowDrop);
        column.addEventListener('drop', drop);
    });
});

