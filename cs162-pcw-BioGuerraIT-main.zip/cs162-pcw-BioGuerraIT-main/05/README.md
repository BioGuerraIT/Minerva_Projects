## Making HTTP requests

This pre-class work can be quite long if you have had no previous exposure to
HTML and web programming. In this case you are encouraged to find someone with
some prior experience and work together. (Conversely, if you do have any prior
experience, then you are encouraged to find someone with no web experience to
help them!)

### HTML Forms

The first time that you usually encounter an HTML request (other than a GET
request) is in an HTML form. The following (freely-available) short course uses
active learning to help you understand HTML forms:
https://developer.mozilla.org/en-US/docs/Learn/HTML/Forms

For this session you will need to work through the following guides:

1. Your first form
2. How to structure a web form
3. The native form controls
4. Sending form data

After which you should feel comfortable tackling questions 1 and 2.

### Python HTTP requests

However, we can also query the web through a python program. There are many
ways of making http requests programmatically. A nice library is the `requests`
library. You can install it using:

```bash
pip3 install requests
```

Now work through [the guide to HTTP requests](https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview).

And then read through the [quickstart for python requests](http://docs.python-requests.org/en/master/user/quickstart/).

### JSON

The web services listed below all return information in a format known as JSON.
Fortunately for us it is straightforward to turn the JSON back into standard
python objects that you are already familiar with.

As an example (borrowed from the requests tutorial), here is a call to github,
which is then read into a python list of python dictionaries:

```python3
>>> import requests
>>> r = requests.get('https://api.github.com/events')
>>> r.json()
[{u'repository': {u'open_issues': 0, u'url': 'https://github.com/...
```

## Questions

### 1. httpbin Form

Using Chrome dev tools, inspect the following form:
https://httpbin.org/forms/post

1. See how the form is structured and how the data is sent to the server.
- Structure:
 <!DOCTYPE html>
<html>
  <head>
  </head>
  <body>
  <!-- Example form from HTML5 spec http://www.w3.org/TR/html5/forms.html#writing-a-form's-user-interface -->
  <form method="post" action="/post">
   <p><label>Customer name: <input name="custname"></label></p>
   <p><label>Telephone: <input type=tel name="custtel"></label></p>
   <p><label>E-mail address: <input type=email name="custemail"></label></p>
   <fieldset>
    <legend> Pizza Size </legend>
    <p><label> <input type=radio name=size value="small"> Small </label></p>
    <p><label> <input type=radio name=size value="medium"> Medium </label></p>
    <p><label> <input type=radio name=size value="large"> Large </label></p>
   </fieldset>
   <fieldset>
    <legend> Pizza Toppings </legend>
    <p><label> <input type=checkbox name="topping" value="bacon"> Bacon </label></p>
    <p><label> <input type=checkbox name="topping" value="cheese"> Extra Cheese </label></p>
    <p><label> <input type=checkbox name="topping" value="onion"> Onion </label></p>
    <p><label> <input type=checkbox name="topping" value="mushroom"> Mushroom </label></p>
   </fieldset>
   <p><label>Preferred delivery time: <input type=time min="11:00" max="21:00" step="900" name="delivery"></label></p>
   <p><label>Delivery instructions: <textarea name="comments"></textarea></label></p>
   <p><button>Submit order</button></p>
  </form>
  </body>
</html>
- How data is sent:
I sent through a post request
{args: {}, data: "", files: {},…}
args
: 
{}
data
: 
""
files
: 
{}
form
: 
{comments: "I want no spicy please", custemail: "bio.guerra@uni.minerva.edu", custname: "Gabriel",…}
headers
: 
{,…}
json
: 
null
origin
: 
"213.121.183.218"
url
: 
"https://httpbin.org/post"

2. Fill in the form and submit it.
This is the response, which is in json formatt
{
  "args": {}, 
  "data": "", 
  "files": {}, 
  "form": {
    "comments": "I want no spicy please", 
    "custemail": "bio.guerra@uni.minerva.edu", 
    "custname": "Gabriel", 
    "custtel": "15406030133", 
    "delivery": "14:30", 
    "size": "medium", 
    "topping": [
      "cheese", 
      "onion"
    ]
  }, 
  "headers": {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7", 
    "Accept-Encoding": "gzip, deflate, br", 
    "Accept-Language": "en-US,en;q=0.9,pt-BR;q=0.8,pt;q=0.7", 
    "Cache-Control": "max-age=0", 
    "Content-Length": "165", 
    "Content-Type": "application/x-www-form-urlencoded", 
    "Host": "httpbin.org", 
    "Origin": "https://httpbin.org", 
    "Referer": "https://httpbin.org/forms/post", 
    "Sec-Ch-Ua": "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"", 
    "Sec-Ch-Ua-Mobile": "?0", 
    "Sec-Ch-Ua-Platform": "\"Windows\"", 
    "Sec-Fetch-Dest": "document", 
    "Sec-Fetch-Mode": "navigate", 
    "Sec-Fetch-Site": "same-origin", 
    "Sec-Fetch-User": "?1", 
    "Upgrade-Insecure-Requests": "1", 
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36", 
    "X-Amzn-Trace-Id": "Root=1-65b19145-7caaf3b41bdd230c4cadbcd7"
  }, 
  "json": null, 
  "origin": "213.121.183.218", 
  "url": "https://httpbin.org/post"
}
3. Make sure to capture the POST request (in the network tab).
Request URL:
https://httpbin.org/post
Request Method:
POST
Status Code:
200 OK
Remote Address:
34.196.123.121:443
Referrer Policy:
strict-origin-when-cross-origin
Access-Control-Allow-Credentials:
true
Access-Control-Allow-Origin:
https://httpbin.org
Content-Length:
1475
Content-Type:
application/json
Date:
Wed, 24 Jan 2024 22:37:57 GMT
Server:
gunicorn/19.9.0
:authority:
httpbin.org
:method:
POST
:path:
/post
:scheme:
https
Accept:
text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding:
gzip, deflate, br
Accept-Language:
en-US,en;q=0.9,pt-BR;q=0.8,pt;q=0.7
Cache-Control:
max-age=0
Content-Length:
165
Content-Type:
application/x-www-form-urlencoded
Origin:
https://httpbin.org
Referer:
https://httpbin.org/forms/post
Sec-Ch-Ua:
"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"
Sec-Ch-Ua-Mobile:
?0
Sec-Ch-Ua-Platform:
"Windows"
Sec-Fetch-Dest:
document
Sec-Fetch-Mode:
navigate
Sec-Fetch-Site:
same-origin
Sec-Fetch-User:
?1
Upgrade-Insecure-Requests:
1
User-Agent:
Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36

### 2. Kanban form

Build on your work from the previous session in which you designed a basic
Kanban website. For today's class you need to build a small HTML form which
will allow you to write a short description of the task which you want to add
to the board. Use inspiration from the httpbin form, and from the HTML form
documentation that you read as part of the pre-class work.

Make sure you have the HTML form ready to paste into a document when you
come to class.

### 3. httpbin Python

Visit [httpbin](https://httpbin.org/) and look at the schema for several of the endpoints and methods.
Using AI tools write working Python code to achieve the following:

1. Successfully log in using basic auth
2. Download an image
3. Generate a UUID4
4. Return a simple JSON response

For learning purposes, please print all the requests and responses so the all
the data can be seen.

You can write a single program which does all of these things, or you can write
several programs, one for each task. Use the requests library, so that it is easier
for everyone to read each other's code.

### 4. (Optional) Public APIs

Browse the following repo:
https://github.com/public-apis/public-apis

1. Find an interesting or whimsical API
2. Write some simple Python code to query the API
3. Bring the code to class!

**Please commit your work to your PCW repo and push it to github before class!**