import requests
from requests.auth import HTTPBasicAuth
import json
import uuid

# Basic Authentication
auth_endpoint = "https://httpbin.org/basic-auth/user/passwd"
auth_response = requests.get(auth_endpoint, auth=HTTPBasicAuth('user', 'passwd'))
print("Auth Response:", auth_response.json())

# Download an Image
image_endpoint = "https://httpbin.org/image"
image_response = requests.get(image_endpoint)
with open('image.png', 'wb') as image_file:
    image_file.write(image_response.content)
print("Image downloaded")

# Generate a UUID4
uuid4_endpoint = "https://httpbin.org/uuid"
uuid4_response = requests.get(uuid4_endpoint)
print("UUID4 Response:", uuid4_response.json())

# Return a Simple JSON Response
json_endpoint = "https://httpbin.org/json"
json_response = requests.get(json_endpoint)
print("JSON Response:", json_response.json())
